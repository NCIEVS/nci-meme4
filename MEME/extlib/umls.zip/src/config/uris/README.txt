Version Information
-------------------
RELEASE=4
VERSION=0.1
DATE=20051028
AUTHORITY=BAC

Uris is not yet ready to be released from this environment.