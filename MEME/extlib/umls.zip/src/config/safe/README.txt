Version Information
-------------------
RELEASE=4
VERSION=1.0
DATE=20051028
AUTHORITY=BAC

This release of the SAFEBOX should contain everything needed. There are no 
changes from prior releases, this is just to make it official 

See INSTALL.txt for installation instructions
