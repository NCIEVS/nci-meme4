Version Information
-------------------
RELEASE=4
VERSION=3.0
DATE=20060331
AUTHORITY=BAC

This release of the MID services should contain everything needed to start and
access the MID services.  Notable updates include:

 o mid-services-data_orig has properties for managing email servers and lists.

See INSTALL.txt for installation instructions

Old Release Information
-----------------------
RELEASE=4
VERSION=2.0
DATE=20060106
AUTHORITY=BAC

This release of the MID services should contain everything needed to start and
access the MID services.  Notable updates include:

 o midsvcs-server.pl was removed and replaced with midsvcs-server.pl_orig.  This way
   the server script can be edited and copied and new updates of MIDSVCS won't 
   overwrite it.

RELEASE=4
VERSION=1.0
DATE=20051028
AUTHORITY=BAC

This release of the MID services should contain everything needed to start and
access the MID services.  There are no changes from prior releases, this is just to
make it official 

