Version Information
-------------------
RELEASE=4
VERSION=0.0
DATE=20061005
AUTHORITY=BAC

This release of the common environment does not add any new environment variables.
Notable changes include:

  o Initial common tools (src & GENERIC)

  o Context buliding sql and scripts

See INSTALL.txt for installation instructions