Version Information
-------------------
RELEASE=4
VERSION=1.0
DATE=20060511
AUTHORITY=SL

This release of the EMS/WMS should contain everything needed to 
operate tools and services.  This is the initial release.