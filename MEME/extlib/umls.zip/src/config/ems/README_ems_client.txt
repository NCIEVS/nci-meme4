Version Information
-------------------
RELEASE=4
VERSION=2.0
DATE=20060613
AUTHORITY=BAC

This release of the EMS client should contain everything needed to 
operate tools and services.  Significant changes include:

 o chemconcepts.pl was added to the client and should be run at the
   end of each insertion.

See INSTALL.txt for installation instructions


Old Release Information
-----------------------
RELEASE=4
VERSION=1.0
DATE=20060511
AUTHORITY=BAC

This release of the EMS client should contain everything needed to 
operate tools and services.  This is the initial release.
