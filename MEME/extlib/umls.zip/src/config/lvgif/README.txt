Version Information
-------------------
RELEASE=4
VERSION=2.0
DATE=20051206
AUTHORITY=BAC

This release of the LVG interface should contain everything needed to start and
access the LVG server.  Notable changes include:

 o Update to lvg_server.pl to use /bin/ps (available on both Solaris and Linux).

 o Update to lvgcgi.pl to use $LVG_HOME instead of $NLS

See INSTALL.txt for installation instructions

Old Release Information
-----------------------
RELEASE=4
VERSION=1.0
DATE=20051028
AUTHORITY=BAC

This release of the LVG interface should contain everything needed to start and
access the LVG server.  There are no changes from prior releases, this is just to
make it official 

