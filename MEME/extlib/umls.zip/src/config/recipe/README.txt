Version Information
-------------------
RELEASE=1
VERSION=1.0
DATE=20060601
AUTHORITY=BAC

This release of the Recipe Writer should contain everything needed to write
recpies in a Windows or UNIX/Linux environment.  This is the first release.

