#!@PATH_TO_PERL@
#
# File:    bt_nt_to_treepos.pl 
# Author:  Deborah Shapiro (6/2000)
#
# REMARKS: This script converts broader than/narrower than relationships 
#          into the treepos format.  It starts by loading the bt_nt_rels.dat
#	   file and the source_atoms.dat file.  It creates the treepos.dat 
#	   file at the end from the bt_nt_treepos table.  When the option 
#	   -addroot is added, the user will be prompted for additional
#	   data regarding the root.
#
# Usage: bt_nt_to_treepos.pl [-addroot]
#
# Porting Status: Ported to oracle
#
# Version Info
# 06/30/2000 (3.1.0) in progress 
$release="3";
$version="1.0";
$version_authority="DSS";
$version_date="06/14/2000";

unshift @INC, "$ENV{ENV_HOME}/bin";
require "env.pl";
use open ":utf8";

#
# Check required environment variables
#
$badargs = 3 if (!($ENV{MEME_HOME}));
$badargs = 7 if (!($ENV{ORACLE_HOME}));

#
# Set variables
#
#$db = "meme";
$db = "oa_mid2005";
$tmp_dir = "/tmp";

#
# Parse arguments
#
while (@ARGV) {
    $arg = shift(@ARGV);
    push (@ARGS, $arg) && next unless $arg =~ /^-/;

    if ($arg eq "-version") {
	$print_version="version";
    }
    elsif ($arg eq "-v") {
	$print_version="v";
    }
    elsif ($arg eq "-help" || $arg eq "--help") {
	$print_help=1;
    }
    elsif ($arg eq "-addroot") {
	$addroot = "1";
	print "Please enter a source_atom_id: ";
	chop($source_atom_id = <STDIN>);
	print "Please enter a hcd: ";
	chop($hcd = <STDIN>);
	$treenum = $source_atom_id;
	print "Please enter a code: ";
	chop($code = <STDIN>);
	print "Please enter an atom name: ";
	chop($atom_name = <STDIN>);
        $termgroup = "SRC/HT";
    }
    elsif ($arg =~ /^-d*/) {
	$db = substr($arg, 2);
    } 
    else {
	$badargs = 1;
	$badswitch = $arg;
    }
}

$userpw=`$ENV{MIDSVCS_HOME}/bin/get-oracle-pwd.pl -d $db`;
chop($userpw);
($user,$passwd) = split /\//, $userpw;

#
# Print Help/Version info, exit
#
&PrintHelp && exit(0) if $print_help;
&PrintVersion($print_version) && exit(0) if $print_version;

#
# Get arguments
#
if (scalar(@ARGS) > 1) {
    $badargs = 2;
    $badopt = $#ARGS+1;
}

#
# Check dependencies
#
$badargs = 4 unless (-e "bt_nt_rels.dat");
$badargs = 6 unless (-e "source_atoms.dat");

if ($addroot && !$source_atom_id) {
    $badargs = 8;
}

if ($addroot && !$atom_name) {
    $badargs = 9;
}
#
# Acquire lock
#
$badargs = 5 unless &AcquireLock;

print "badargs = $badargs \n";
#
# Print bad argument errors if any found
#
if ($badargs) {
    %errors = (1 => "Illegal switch: $badswitch",
	       2 => "Wrong number of arguments: $badopt",
	       3 => "\$MEME_HOME must be set.",
	       4 => "Cannot find required file: bt_nt_rels.dat.",
	       5 => qq{Could not acquire lock:  
    Someone else is currently building contexts.  You must wait
    until they are finished and then proceed.},
	       6 => "Cannot find required file: source_atoms.dat.",
	       7 => "\$ORACLE_HOME must be set.",
	       8 => "source_atom_id must be entered.",
	       9 => "atom_name must be entered."
 );
    &PrintUsage;
    print "\n$errors{$badargs}\n";
    exit(0);
};

#
# This section calls the MEME_OPERATIONS function assign_cuis
#
use DBI;
use DBD::Oracle;

#
# Program logic
#
print qq{
-------------------------------------------------
Starting ... },scalar(localtime),qq{
-------------------------------------------------
User is $userpw
DB is $db
};
&PrintVersion;

if ($addroot) {
    print qq{
   source_atom_id is set to $source_atom_id
   hcd is set to $hcd
   termgroup is set to $termgroup
   code is set to $code
   atom_name is set to $atom_name

};
}

system("$ENV{INV_HOME}/bin/confirm_cxt_sql.csh","$db");
if ($?) {
	print "Error verifying the required sql infrastructure for inversion process\n";
	exit($?);
}    

# open connection
$dbh = DBI->connect("dbi:Oracle:$db", "$user", "$passwd")
   or (&ReleaseLock && die "Can't connect to Oracle database: $DBI::errstr\n");

# Enable buffer
&EnableBuffer;


print "\n";
print "    Write treepos table to file ...",scalar(localtime),"\n";

open (TREEPOS,">treepos.tmp") || (&ReleaseLock && die "Could not open treepos.tmp: $? $!\n");

$sh = $dbh->prepare( qq{
    SELECT source_atom_id, hcd, treenum, rela, sort_field
    FROM treepos
}) ||  (&ReleaseLock && die "Can't prepare statement: $DBI::errstr");

$sh->execute || (&FlushBuffer && &ReleaseLock && die);
while (@fields = $sh->fetchrow_array) {
    print TREEPOS join("|",@fields),"\n";
}
close(TREEPOS);
(&ReleaseLock && die "Error: $sh->errstr") if $sh->err;

#
# If addroot, fix up treepos, source_atoms.dat
#
if ($addroot) {
    open (F,"treepos.tmp") || (&ReleaseLock && die "Could not open treepos.tmp: $? $!\n");
    open (F2,">treepos.tmp2") || (&ReleaseLock && die "Could not open treepos.tmp2: $? $!\n");
    while (<F>) {
        chop;
	@fields = split /\|/;
	print F2 "$fields[0]|$fields[1]|${source_atom_id}.$fields[2]|$fields[3]|$fields[4]\n";
    }
    print F2 "$source_atom_id|$hcd|$treenum|$rela|\n";
    close(F);
    close(F2);

    rename "treepos.tmp2", "treepos.tmp";

    open (F,">>source_atoms.dat") || 
        (&ReleaseLock && die "Could not open source_atoms.dat: $? $!\n");
    print F "$source_atom_id|$termgroup|$code|$atom_name||||\n";
    close(F);
 }

unlink "treepos.dat";
system "/bin/sort -o treepos.dat treepos.tmp";
unlink "treepos.tmp";


print qq{
-------------------------------------------------
Finished ... },scalar(localtime),qq{
-------------------------------------------------
};

&ReleaseLock;

exit 0;

####### Local Procedures #######
sub AcquireLock {
    $SIG{INT} = sub {&ReleaseLock; exit 0;};
    open (L,">$tmp_dir/lock.$$") || 
       die "Could not open lockfile: $? $!\n";
    $x =  `ls $ENV{MEME_HOME}/Contexts | egrep -c '^lock\.'`;
    if($x != 1) {
      &ReleaseLock;
      return 0;
    }
     
    return 1;
}

sub ReleaseLock {
    close(LOCK);
    unlink "$tmp_dir/lock.$$";
    return 1;
}

sub EnableBuffer {
    my($size) = @_;
    $size = 100000 unless $size;
    $sh = $dbh->prepare(qq{
    BEGIN
	dbms_output.enable($size);
    END;});
    $sh->execute;
} # end EnableBuffer

sub FlushBuffer {
   #prepare stmt
    $sh = $dbh->prepare(q{
    BEGIN
	dbms_output.get_line(:line,:status);
    END;});
    #bind parms
    $sh->bind_param_inout(":line", \$line, 256);
    $sh->bind_param_inout(":status", \$status,38);

    # flush buffer
    do {
	$sh->execute;
	print "$line\n";
    } while (!$status);

} # end FlushBuffer

sub PrintVersion {
    my($type) = @_;
    print "Release $release: version $version, ".
          "$version_date ($version_authority).\n"
          if $type eq "version";
    print "$version\n" if $type eq "v";
    return 1;
}

sub PrintUsage {

    print qq{ This script has the following usage:
 Usage: bt_nt_to_treepos.pl [-addroot]
    };
}

sub PrintHelp {
    &PrintUsage;
    print qq{
 This script converts broader than/narrower than relationships 
 into the treepos format.  It starts by loading the bt_nt_rels.dat
 file and the source_atoms.dat file. It creates the treepos.dat file 
 from the bt_nt_treepos table.  When the option -addroot is added, the 
 user will be prompted for additional information regarding the root. 

  $usage

  Options:
         -v[ersion]:             Print version information
         -[-]help:               On-line help
};
    &PrintVersion("version");
    return 1;
}
