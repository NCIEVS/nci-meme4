#!@PATH_TO_PERL@
#
# File:    ranges_to_bt_nt.pl 
# Author:  Deborah Shapiro (6/2000)
#
# REMARKS: This script converts a code ranges formatted file
#          into the bt_nt format.  It starts by loading the code_ranges.dat
#          file into a table called code_ranges.  It creates the bt_nt_rels.dat
#          file at the end from the bt_nt_rels table.  If no option flag is
#          indicated the code ranges are assumed to be simple.  If the
#          -prefix flag is included than the ranges are explected to be of
#          the prefix hierarchy type.
#
# Usage: ranges_to_bt_nt.pl [-prefix] [-d<db_name>]
#
# Porting Status: Ported to oracle
#
# Version Info
# 06/30/2000 (3.1.0) in progress 
$release="3";
$version="1.0";
$version_authority="DSS";
$version_date="06/14/2000";

unshift @INC, "$ENV{ENV_HOME}/bin";
require "env.pl";
use open ":utf8";

#
# Check required environment variables
#
$badargs = 3 if (!($ENV{MEME_HOME}));
$badargs = 7 if (!($ENV{ORACLE_HOME}));

#
# Set variables
#
$db = "meme";
$prefix = 0;
$tmp_dir = "/tmp";

#
# Parse arguments
#
while (@ARGV) {
    $arg = shift(@ARGV);
    push (@ARGS, $arg) && next unless $arg =~ /^-/;

    if ($arg eq "-version") {
	$print_version="version";
    }
    elsif ($arg eq "-v") {
	$print_version="v";
    }
    elsif ($arg eq "-help" || $arg eq "--help") {
	$print_help=1;
    }
    elsif ($arg eq "-prefix") {
	$prefix = 1;
    } 
    elsif ($arg =~ /^-d*/) {
        $db = substr($arg, 2);
    }
    else {
	$badargs = 1;
	$badswitch = $arg;
    }
}

$userpw=`$ENV{MIDSVCS_HOME}/bin/get-oracle-pwd.pl -d $db`;
chop($userpw);
($user,$passwd) = split /\//, $userpw;

#
# Print Help/Version info, exit
#
&PrintHelp && exit(0) if $print_help;
&PrintVersion($print_version) && exit(0) if $print_version;

#
# Get arguments
#
if (scalar(@ARGS) > 1) {
    $badargs = 2;
    $badopt = $#ARGS+1;
}

#
# Check dependencies
#
$badargs = 4 unless (-e "code_ranges.dat");
$badargs = 6 unless (-e "source_atoms.dat");

#
# Acquire lock
#
$badargs = 5 unless &AcquireLock;

#
# Print bad argument errors if any found
#
if ($badargs) {
    %errors = (1 => "Illegal switch: $badswitch",
	       2 => "Wrong number of arguments: $badopt",
	       3 => "\$MEME_HOME must be set.",
	       4 => "Cannot find required file: code_ranges.dat.",
	       5 => qq{Could not acquire lock:  
    Someone else is currently building contexts.  You must wait
    until they are finished and then proceed.},
	       6 => "Cannot find required file: source_atoms.dat.",
	       7 => "\$ORACLE_HOME must be set.",
 );
    &PrintUsage;
    print "\n$errors{$badargs}\n";
    exit(0);
};

#
# This section calls the MEME_OPERATIONS function assign_cuis
#
use DBI;
use DBD::Oracle;

#
# Program logic
#
print qq{
-------------------------------------------------
Starting ... },scalar(localtime),qq{
-------------------------------------------------
User is $userpw
DB is $db
};
&PrintVersion;

if ($prefix) {
  print "Source is a prefix formatted source.\n";
}

system("$ENV{INV_HOME}/bin/confirm_cxt_sql.csh","$db");
if ($?) {
	print "Error verifying the required sql infrastructure for inversion process\n";
	exit($?);
}    
    
print "    Start load of code_ranges ...",scalar(localtime),"\n";
print "$ENV{ORACLE_HOME}/bin/sqlldr $userpw\@$db control='$tmp_dir/code_ranges.ctl'";
open(CR_CTL, ">$tmp_dir/code_ranges.ctl") or die "Can't open ctl file, '$tmp_dir/code_ranges.ctl', $!";
print CR_CTL<<EOT;
options (rows=10000, bindsize=10000000, readsize=10000000)
load data
infile 'code_ranges'
badfile 'code_ranges'
discardfile 'code_ranges'
truncate
into table code_ranges
fields terminated by '|'
trailing nullcols
(source_atom_id          integer external,
 context_level           integer external,
 low_range               char,
 high_range              char
)
EOT
close CR_CTL;
print system "$ENV{ORACLE_HOME}/bin/sqlldr", "$userpw\@$db control='$tmp_dir/code_ranges.ctl'";
if ($?)  {
  print "Error loading code_ranges.\n"; 
  &ReleaseLock;
  exit $?;
}
print "\n    Loaded code_ranges successfully ...",scalar(localtime),"\n";
unlink "$tmp_dir/code_ranges.ctl";

print "    Start load of source_atoms ...",scalar(localtime),"\n";
open(SA_CTL, ">$tmp_dir/source_atoms.ctl") or die "Can't open ctl file, '$tmp_dir/source_atoms.ctl', $!";
print SA_CTL<<EOT;
options (rows=10000, bindsize=10000000, readsize=10000000)
load data
infile 'source_atoms'
badfile 'source_atoms'
discardfile 'source_atoms'
truncate
into table source_atoms 
fields terminated by '|' 
trailing nullcols
(source_atom_id          integer external,
 termgroup               char,
 code                    char,
 atom_name               char(3000),
 hcd                     char(1000),
 sg_id                   char(50),
 sg_type                 char(50),
 sg_qualifier            char(50)
 )
EOT
close SA_CTL;
print system "$ENV{ORACLE_HOME}/bin/sqlldr", "$userpw\@$db control='$tmp_dir/source_atoms.ctl'";
if ($?)  {
  print "Error loading source_atoms.\n"; 
  &ReleaseLock;
  exit $?;
}
print "    Loaded source_atoms successfully ...",scalar(localtime),"\n";
print "\n";
unlink "$tmp_dir/source_atoms.ctl";

# open connection
$dbh = DBI->connect("dbi:Oracle:$db", "$user", "$passwd")
   or (&ReleaseLock && die "Can't connect to Oracle database: $DBI::errstr\n");

# Enable buffer
&EnableBuffer;

# prepare statement
print "    Truncate bt_nt_rels table ...",scalar(localtime),"\n";
$sh = $dbh->prepare(qq{
    BEGIN
        MEME_SYSTEM.truncate('bt_nt_rels');
    END;});

# execute statement & flush buffer
$sh->execute;
&FlushBuffer;

# prepare statement
print "    Drop indexes for bt_nt_rels ...",scalar(localtime),"\n";
$sh = $dbh->prepare(qq{
    BEGIN
        MEME_SYSTEM.drop_indexes('bt_nt_rels');
    END;});

# execute statement & flush buffer
$sh->execute;
&FlushBuffer;

# prepare statement
print "    Compute statistics for data tables ...",scalar(localtime),"\n";
$sh = $dbh->prepare(qq{
    BEGIN
        MEME_SYSTEM.analyze('source_atoms');
        MEME_SYSTEM.analyze('code_ranges');
    END;});

# execute statement & flush buffer
$sh->execute;
&FlushBuffer;

# prepare statement
print "    Generate bt_nt_rels from code_ranges...",scalar(localtime),"\n";
$retval = 0;
if($prefix) {
  $sh = $dbh->prepare(qq{
    BEGIN
        :retval := MEME_CONTEXTS.prefix_ranges_to_bt_nt;
    END;});
} else {
  $sh = $dbh->prepare(qq{
    BEGIN
        :retval := MEME_CONTEXTS.ranges_to_bt_nt;
    END;});
}
# bind parameters
$sh->bind_param_inout(":retval", \$retval, 12);

# execute statement & flush buffer
$sh->execute;
&FlushBuffer;
print "    Finished generating bt_nt_rels from code_ranges ...",scalar(localtime),"\n";

# prepare statement
print "    Drop bt_options table ...",scalar(localtime),"\n";
$sh = $dbh->prepare(qq{
    BEGIN
        MEME_UTILITY.drop_it('table', 'bt_options');
    END;});

# execute statement & flush buffer
$sh->execute;
&FlushBuffer;

# do statement
print "    Recreating indexes on bt_nt_rels ...",scalar(localtime),"\n";
$sh = $dbh->do(q{ create index X_BTNT_1 on bt_nt_rels(source_atom_id_1) compute statistics parallel});

$sh = $dbh->do(q{ create index X_BTNT_2 on bt_nt_rels(source_atom_id_2) compute statistics parallel});

print "\n";
print "    Write bt_nt_rels table to file ...",scalar(localtime),"\n";

open (BTNT,">bt_nt_rels.tmp") || (&ReleaseLock && die "Could not open bt_nt_rels.tmp: $? $!\n");

$sh = $dbh->prepare( qq{
    SELECT source_atom_id_1, rel, rela, source_atom_id_2
    FROM bt_nt_rels 
}) ||  (&ReleaseLock && die "Can't prepare statement: $DBI::errstr");

$sh->execute;
while (@fields = $sh->fetchrow_array) {
    print BTNT join("|",@fields),"\n";
}
close(BTNT);
(&ReleaseLock && die "Error: $sh->errstr") if $sh->err;

unlink "bt_nt_rels.dat";
system "/bin/sort -o bt_nt_rels.dat bt_nt_rels.tmp";
unlink "bt_nt_rels.tmp";

unlink "$tmp_dir/source_atoms.ctl";
unlink "$tmp_dir/code_ranges.ctl";


print qq{
-------------------------------------------------
Finished ... },scalar(localtime),qq{
-------------------------------------------------
};

&ReleaseLock;

exit 0;

####### Local Procedures #######
sub AcquireLock {
    $SIG{INT} = \&ReleaseLock; 
    open (LOCK,">$tmp_dir/lock.$$") || 
       die "Could not open lockfile: $? $!\n";
    $x =  `ls $tmp_dir | egrep -c '^lock\.'`;
    if($x != 1) {
      &ReleaseLock;
      return 0;
    }
     
    $x=`user_info.pl`;
    print LOCK "$x\n";
    close(LOCK);
    return 1;
}

sub ReleaseLock {
    unlink "$tmp_dir/lock.$$";
    return 1;
}

sub EnableBuffer {
    my($size) = @_;
    $size = 100000 unless $size;
    $sh = $dbh->prepare(qq{
    BEGIN
	dbms_output.enable($size);
    END;});
    $sh->execute;
} # end EnableBuffer

sub FlushBuffer {
   #prepare stmt
    $sh = $dbh->prepare(q{
    BEGIN
	dbms_output.get_line(:line,:status);
    END;});
    #bind parms
    $sh->bind_param_inout(":line", \$line, 256);
    $sh->bind_param_inout(":status", \$status,38);

    # flush buffer
    do {
	$sh->execute;
	print "$line\n";
    } while (!$status);

} # end FlushBuffer

sub PrintVersion {
    my($type) = @_;
    print "Release $release: version $version, ".
          "$version_date ($version_authority).\n"
          if $type eq "version";
    print "$version\n" if $type eq "v";
    return 1;
}

sub PrintUsage {

    print qq{ This script has the following usage:
 Usage: ranges_to_bt_nt.pl [-prefix] [-d<db_name>]
    };
}

sub PrintHelp {
    &PrintUsage;
    print qq{
 This script converts a code ranges formatted file
 into the bt_nt format.  It starts by loading the code_ranges.dat
 file into a table called code_ranges.  It creates the bt_nt_rels.dat
 file at the end from the bt_nt_rels table.  If no option flag is
 indicated the code ranges are assumed to be simple.  If the
 -prefix flag is included than the ranges are explected to be of
 the prefix hierarchy type.

  $usage

  Options:
         -v[ersion]:             Print version information
         -[-]help:               On-line help
};
    &PrintVersion("version");
    return 1;
}
