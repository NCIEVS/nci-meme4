#!@PATH_TO_PERL@
#
# File:		qa_ranges.pl
# Author:	Deborah Shapiro
# 
# This script has the following usage:
# qa_ranges.pl
# code_ranges.dat and source_atoms.dat must exist in calling directory
#
# Options:
#	-v[ersion]:	Print version information
#	-[-]help:	On-line help
#
# 1. Check that every source_atom_id in source_atoms.dat fits into one of the
# ranges from code_ranges.dat
# 2. Check that every code_range in code_ranges.dat fits into a parent 
# code range from the same file.  The root(s) are exceptions and 
# will be printed out.
# 3. Check that there should be no parent (broader) range with a higher
# context level than the context level of the child (narrower) range
# 
# Version information
# 6/21/2000 3.1.0: 
#
$release = "3";
$version = "1.0";
$version_date = "6/21/2000";
$version_authority="DSS";

unshift @INC, "$ENV{ENV_HOME}/bin";
require "env.pl";
use open ":utf8";

#
# Parse arguments
#
while(@ARGV) {
    $arg = shift(@ARGV);
    push (@ARGS, $arg) && next unless $arg =~ /^-/;

    if ($arg eq "-v") {
        $print_version="v";
    }
    elsif ($arg eq "-version") {
        $print_version="version";
    }
    elsif ($arg eq "-help" || $arg eq "--help") {
        $print_help=1;
    }
    else {
        $badargs = 1;
	$badswitch = $arg;
    }
}

#
# Print Help/Version info, exit
#
&PrintHelp && exit(0) if $print_help;
&PrintVersion($print_version) && exit(0) if $print_version;


#
# Check dependencies
#
if ( !(-e "code_ranges.dat")) {
   $badargs = 2;
}

if ( !(-e "source_atoms.dat")) {
   $badargs = 3;
}

#
# Print bad argument errors if any found
#
if ($badargs) {
    %errors = (1 => "Illegal switch: $badswitch",
	       2 => "Cannot fine code_ranges.dat; exiting...",
	       3 => "Cannot find source_atoms.dat; exiting..."
	      );
    &PrintUsage;
    print "\n$errors{$badargs}\n";
    exit(0);
}

#
# Program Logic
#

$CODE_RANGES = "code_ranges.dat";
open CODE_RANGES;
$SOURCE_ATOMS = "source_atoms.dat";
open SOURCE_ATOMS;

# Load code_ranges.dat into CodeRanges array
while (<CODE_RANGES>) {
   @tmp = split /\|/;
   push @CodeRanges, [@tmp];
}

# Check that every source_atom_id in source_atoms.dat fits into one of the
# ranges from code_ranges.dat
print "source atoms not in a code range\n";
LOOP: while (<SOURCE_ATOMS>) {
   @tmp = split /\|/;
   for ($j=0; $j <= $#CodeRanges; $j++) {
     if($CodeRanges[$j][0] == $tmp[0]){
	next LOOP;
     }
   }
   for ($i=0; $i <= $#CodeRanges; $i++) {
     if($CodeRanges[$i][2] <= $tmp[2] && $CodeRanges[$i][3] >= $tmp[2]) {
       next LOOP;
     } 
   }
   print $tmp[0], " ", $tmp[2], "\n";
}

close $CODE_RANGES;
open CODE_RANGES;

# Check that every code_range in code_ranges.dat fits into a parent 
# code range from the same file.  The root(s) are exceptions and 
# will be printed out.
print "\ncode ranges not contained within another code range of the immediate next level up\n(e.g. a range at level 4 must be the subset of a range at level 3)\n";
LOOP2: while (<CODE_RANGES>) {
   @tmp = split /\|/;
   for ($i=0; $i <= $#CodeRanges; $i++) {
     if((($tmp[2]) =~ /^[0-9\.]*$/) && (($tmp[3]) =~ /^[0-9\.]*$/)) {
        if(($CodeRanges[$i][2] < $tmp[2] && $CodeRanges[$i][3] > $tmp[3]
	     && ($CodeRanges[$i][1] + 1 == $tmp[1]))||
           ($CodeRanges[$i][2] <= $tmp[2] && $CodeRanges[$i][3] > $tmp[3]
	     && ($CodeRanges[$i][1] + 1 == $tmp[1]))||
           ($CodeRanges[$i][2] < $tmp[2] && $CodeRanges[$i][3] >= $tmp[3]
	     && ($CodeRanges[$i][1] + 1 == $tmp[1]))||
	   ($CodeRanges[$i][2] == $tmp[2] && $CodeRanges[$i][3] == $tmp[3] 
	     && ($CodeRanges[$i][1] + 1 == $tmp[1]))) {
           next LOOP2;
        } 
     } 
     else {
        if(($CodeRanges[$i][2] lt $tmp[2] && $CodeRanges[$i][3] gt $tmp[3]
	     && ($CodeRanges[$i][1] + 1 == $tmp[1]))||
           ($CodeRanges[$i][2] le $tmp[2] && $CodeRanges[$i][3] gt $tmp[3]
	     && ($CodeRanges[$i][1] + 1 == $tmp[1]))||
           ($CodeRanges[$i][2] lt $tmp[2] && $CodeRanges[$i][3] ge $tmp[3]
	     && ($CodeRanges[$i][1] + 1 == $tmp[1]))||
	   ($CodeRanges[$i][2] eq $tmp[2] && $CodeRanges[$i][3] eq $tmp[3] 
	     && ($CodeRanges[$i][1] + 1 == $tmp[1]))) {
           next LOOP2;
        } 
     }
   }

   if($tmp[1] != '00') {
     print $tmp[0], " ", $tmp[1], " ", $tmp[2], " ", $tmp[3], "\n";
   }
}

close $CODE_RANGES;
open CODE_RANGES;

# Check that there should be no parent (broader) range with a higher
# context level than the context level of the child (narrower) range
print "\nparent code ranges with a higher context level than their child\n";
LOOP3: while (<CODE_RANGES>) {
   @tmp = split /\|/;
   for ($i=0; $i <= $#CodeRanges; $i++) {
     if(($CodeRanges[$i][2] < $tmp[2] && $CodeRanges[$i][3] > $tmp[3]
	   && $CodeRanges[$i][1] > $tmp[1]) || 
        ($CodeRanges[$i][2] <= $tmp[2] && $CodeRanges[$i][3] > $tmp[3]
	   && $CodeRanges[$i][1] > $tmp[1]) || 
        ($CodeRanges[$i][2] < $tmp[2] && $CodeRanges[$i][3] >= $tmp[3]
	   && $CodeRanges[$i][1] > $tmp[1])) {  
       print $tmp[0], " ", $tmp[1], " ", $tmp[2], " ", $tmp[3], "\n";
     }
   }
   next LOOP3;
}

#
# Cleanup & Exit
#
close $CODE_RANGES;
close $SOURCE_ATOMS;
exit (0);

############################# local procedures ################################
sub PrintVersion {
    my($type) = @_;
    print "Release $release: version $version, ".
          "$version_date ($version_authority).\n" 
          if $type eq "version";
    print "$version\n" if $type eq "v";
    return 1;
}

sub PrintUsage {
    print qq{ This script has the following usage:
  qa_ranges.pl 
    };
}

sub PrintHelp {
    &PrintUsage;
    print qq{
  Options:
        -v[ersion]:     Print version information.
        -[-]help:       On-line help
    };
    &PrintVersion("version");
    return 1;
}

