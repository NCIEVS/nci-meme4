#!@PATH_TO_PERL@
#
# File:		cx3trunc.pl
# Author:	Nels Olson/Deborah Shapiro
# 
# This script has the following usage:
# cx3trunc.pl <source>
# source.raw3 must exist in calling directory
#
# Options:
#	-v[ersion]:	Print version information
#	-[-]help:	On-line help
#
# prints CX lines into <source>.all:
# "{termid}|cid|hcd|ANC\tSELF\tCHD\tSIB"    where:
# ANC is:  root~anc2~...~parent
# SELF is: self
# CHD is:  chd1[^]~chd2[^]~...~chdK[^]
# SIB is:  sib1[^]~sib2[^]~...~sibJ[^]    ([^] is optional has-children flag)
#
# prints out a stat_report.log
# alerts user of concepts with more than 99 contexts 
#                concepts with more than 200 siblings
# distributions are then displayed for 
#                number of concepts with various ranges of sibling numbers
#                number of concepts with various ranges of contexts
# 
# Version information
# 01/06/2006 3.1.2: Fixed to properly truncate the last context in the file
# 05/05/2003 3.1.1: Limits number of entries for a single source atom id
#                   to $MAX_COUNT (currently = 10).
# 6/21/2000 3.1.0: Script changed from cx.pl to work with <source>.raw3 input rather
#				than <source>.raw2 input
$release = "3";
$version = "1.2";
$version_date = "01/06/2006";
$version_authority="NEO";

unshift @INC, "$ENV{ENV_HOME}/bin";
require "env.pl";
use open ":utf8";

#
# Parse arguments
#
while(@ARGV) {
    $arg = shift(@ARGV);
    push (@ARGS, $arg) && next unless $arg =~ /^-/;

    if ($arg eq "-v") {
        $print_version="v";
    }
    elsif ($arg eq "-version") {
        $print_version="version";
    }
    elsif ($arg eq "-help" || $arg eq "--help") {
        $print_help=1;
    }
    else {
        $badargs = 1;
	$badswitch = $arg;
    }
}

#
# Print Help/Version info, exit
#
&PrintHelp && exit(0) if $print_help;
&PrintVersion($print_version) && exit(0) if $print_version;

#
# Get arguments
#
if ($badargs) {
}
elsif (scalar(@ARGS) == 1) {
    ($source) = @ARGS;
}
else {
    $badargs = 2;
    $badopt = $#ARGS+1;
}

#
# Check dependencies
#
print "$source.raw3\n";
if ( !(-e "$source.raw3")) {
   $badargs = 3;
}

#
# Print bad argument errors if any found
#
if ($badargs) {
    %errors = (1 => "Illegal switch: $badswitch",
	       2 => "Bad number of arguments: $badopt",
	       3 => "Cannot find $source.raw3; exiting..."
	      );
    &PrintUsage;
    print "\n$errors{$badargs}\n";
    exit(0);
}

#
# Program Logic
#

$\ = "\n";		# set output record separator
$MAX_COUNT = 10;
open(STAT_REPORT, ">stat_report.log");
$SOURCE = $source.".raw3";
$SOURCE_OUT = $source.".all";
open SOURCE;
open STDOUT, ">$SOURCE_OUT";

while (<SOURCE>) {
    ($tmid,$cid,$level,$sort,$term,$code,$hcd,$rel,$xc) =
	/([^|]*)\|([^|]*)\|([^|]*)\|([^|]*)\|([^|]*)\|[^|]*\|([^|]*)\|([^|]*)\|([^|]*)\|([^|\n]*)/;

    #
    # Stop if $cid exceeds $MAX_COUNT
    #
    if ($cid > $MAX_COUNT) {
      print "$tmid|$cid|$hcd|	$term	More contexts not shown" if $level eq " 0" && $cid == ($MAX_COUNT+1);
      next;
    }

    $cid =~ s/ +//;
    $tmid =~ s/ +//;
    $xc = ($xc eq '1') ? '^' : '';
    if ($tmid != $lasttmid  ||  $cid != $lastcid) {
	print {STAT_REPORT} $lasttmid, "  concept_id: ", $lastcid, "  siblings: ", $sibling_counter if $sibling_counter > 200;
	$cids[$lastcid] += 1 if $tmid != $lasttmid;
	if ($tmid != $lasttmid && $cid != $lastcid) {
	    print {STAT_REPORT} $lasttmid, "  contexts: ", $lastcid if $lastcid > 99;
	}
	$lasttmid=$tmid; $lastcid=$cid;
	if ($chd_counter > 100) {
	    $line .= '~[CHILDREN AFTER THE FIRST 100 HAVE BEEN TRUNCATED]';
	}
	$chd_counter = 0;
	if ($line ne '') {
	    $line .= "\t" x (3 - $lastpart);
	    $line =~ s/(\t[^\t]*)(\t[^\t]*)$/$2$1/;
	    $siblings[$sibling_counter/10]+=1;
	    $sibling_counter = 0;
	    print $line;
	}
	$lastpart=0;
	$first=1;
	$line = '';
    }
    $part = ($level < 50) ? 0 : ($level == 50) ? 1 : ($level == 60) ? 2 : 3;
    if ($part != $lastpart) {
	$line .= "\t" x ($part - $lastpart);
	$lastpart = $part;
	$first=1;
    }
    $chd_counter++ if $part == 3;
    unless ($chd_counter > 100) {
	$line .= '~' unless $first;
	$first=0;
	$xc = '' if $part<2;	# no child-flags needed on ancestors or self's
	$line .= "$term$xc";
	$sibling_counter++ if $part == 2;
	$line = "$tmid|$cid|$hcd|$line" if $part == 1;
    }
}

print {STAT_REPORT} $lasttmid, "  concept_id: ", $lastcid, "  siblings: ", $sibling_counter if $sibling_counter > 200;
$cids[$lastcid] += 1;
print {STAT_REPORT} $lasttmid, "  contexts: ", $lastcid if $lastcid > 99;
if ($chd_counter > 100) {
    $line .= '~[CHILDREN AFTER THE FIRST 100 HAVE BEEN TRUNCATED]';
}
$line .= "\t" x (3 - $lastpart);
$line =~ s/(\t[^\t]*)(\t[^\t]*)$/$2$1/;
$siblings[$sibling_counter/10]+=1;
print $line;

print {STAT_REPORT} "\n", "siblings", "\t", "num of concepts";
for($index = 0; $index<=$#siblings; $index++ ) {  
    print {STAT_REPORT} ($index*10), "-", ($index*10)+9, "\t\t", $siblings[$index]; 
} 

print {STAT_REPORT} "\n", "contexts", "\t", "num of concepts";
for($index = 1; $index<=$#cids; $index++ ) {  
    print {STAT_REPORT} $index, "\t\t", $cids[$index]; 
} 

#
# Cleanup & Exit
#
close $SOURCE;
close $STAT_REPORT;	
close $STDOUT;
exit (0);

############################# local procedures ################################
sub PrintVersion {
    my($type) = @_;
    print "Release $release: version $version, ".
          "$version_date ($version_authority).\n" 
          if $type eq "version";
    print "$version\n" if $type eq "v";
    return 1;
}

sub PrintUsage {
    print qq{ This script has the following usage:
  cx3.pl <SAB> (SAB = Source Abbrev.)
  <SAB>.raw3 must be located in the calling directory
    };
}

sub PrintHelp {
    &PrintUsage;
    print qq{
  Options:
        -v[ersion]:     Print version information.
        -[-]help:       On-line help
    };
    &PrintVersion("version");
    return 1;
}

