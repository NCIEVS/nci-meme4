#!@PATH_TO_PERL@
#
# File:    process_contexts.pl 
# Author:  Deborah Shapiro (6/2000)
#
# REMARKS: This script loads the treepos and source_atoms tables
#          and calls the context processing functions.  It then makes a
#         <file_name>[.raw3] file from the contents of contexts_raw table.
#          The various start options.
#               1  generate ancestors and children only
#               2  generate ancestors, children, and all siblings
#               3  generate ancestors, children, and some siblings
#                       (req. exclude_table)
#               4  return the count of the number of siblings but
#                       don't put them in .raw3 file
#
# Usage: process_contexts.pl [-d<db_name>]
#
# Porting Status: Ported to oracle
#
# Version Info
# 05/05/2003 (3.1.1) Supports the "use_rela" flag for context generation
# 06/30/2000 (3.1.0) in progress 
$release="3";
$version="1.1";
$version_authority="DSS";
$version_date="05/05/2003";

unshift @INC, "$ENV{ENV_HOME}/bin";
require "env.pl";
use open ":utf8";

#
# Check required environment variables
#
$badargs = 3 if (!($ENV{MEME_HOME}));
$badargs = 7 if (!($ENV{ORACLE_HOME}));

#
# Set variables
#
$db = "meme";
#$db = "oa_mid2005";
$user_info = `user_info.pl $$`;
$|=1;
$use_rela = "Y";
$ENV{"LANG"} = "en_US.UTF-8";
$ENV{"LC_COLLATE"} = "C";
$dir = $rawdir = ".";

#
# Parse arguments
#
while (@ARGV) {
    $arg = shift(@ARGV);
    #push (@ARGS, $arg) && next unless $arg =~ /^-/;

    if ($arg eq "-version") {
	$print_version="version";
    }
    elsif ($arg eq "-v") {
	$print_version="v";
    }
    elsif ($arg eq "-help" || $arg eq "--help") {
	$print_help=1;
    } 
    elsif ($arg eq "-l") {
		$dir = shift(@ARGV);
		$rawdir = "../tmp";
		print "Reading SA/TP from: $dir\n";
		print "Writing raw3 file to: $rawdir\n"

    }
    elsif ($arg =~ /^-d.+/) {
       $db = substr($arg, 2);
    }
    elsif ($arg =~ /^-ignore_rela$/) {
       $use_rela = "N";
    }
    else {
	$badargs = 1;
	$badswitch = $arg;
    }
}

$userpw=`$ENV{MIDSVCS_HOME}/bin/get-oracle-pwd.pl -d $db`;
chop($userpw);
($user,$passwd) = split /\//, $userpw;

unless(($print_help) || ($print_version eq "v") || ($print_version eq "version")){
    print "Please enter the name of the source: ";
    chop($source_of_context = <STDIN>);
    print "Please enter the output file name (w or w/out the .raw3 extension): ";
    chop($raw3_file_name = <STDIN>);
	# add the extension if it is not there
	if ($raw3_file_name !~ /.*\.raw3$/) {
		$raw3_file_name .= ".raw3";
	}

    print "Please enter a start option (1-4, default is anc, chd, & sibs): ";
    chop($startop = <STDIN>);

    if(!$startop) {
      $startop = 2;
    }

    if(($startop == 2) || ($startop == 3)) {
	$insert_sibs = 1;
    }
    else {
	$insert_sibs = 0;
	}
}

#
# Print Help/Version info, exit
#
&PrintHelp && exit(0) if $print_help;
&PrintVersion($print_version) && exit(0) if $print_version;

#
# Get arguments
#
unless(-e $rawdir) {
	$badargs = 2;
}

#
# Check dependencies
#
$badargs = 4 unless (-e "$dir/treepos.dat");
$badargs = 6 unless (-e "$dir/source_atoms.dat");
if($startop == 3) {
  $badargs = 8 unless (-e "$dir/exclude_list.dat");
}

#
# Acquire lock
#
$tmp_dir = "/tmp";
$badargs = 5 unless &AcquireLock;

#
# Print bad argument errors if any found
#
if ($badargs) {
    %errors = (1 => "Illegal switch: $badswitch",
	       2 => "The dir to write raw3: '$rawdir' does not exist",
	       3 => "\$MEME_HOME must be set.",
	       4 => "Cannot find required file: $dir/treepos.dat.",
	       5 => qq{Could not acquire lock:  
    Someone else is currently building contexts.  You must wait
    until they are finished and then proceed.},
	       6 => "Cannot find required file: $dir/source_atoms.dat.",
	       7 => "\$ORACLE_HOME must be set.",
	       8 => "Cannot find required file: $dir/exclude_list.dat."
 );
    &PrintUsage;
    print "\n$errors{$badargs}\n";
    exit(0);
};

#
# This section calls the MEME_OPERATIONS function assign_cuis
#
use DBI;
use DBD::Oracle;


#
# Create the .ctl files
#
&CreateCTLfile();
 
#
# Program logic
#
print qq{
-------------------------------------------------
Starting ... },scalar(localtime),qq{
-------------------------------------------------
User is $userpw
DB is $db
};
&PrintVersion;

print qq{
   source_name is set to $source_of_context
   raw3 file name is set to $raw3_file_name
   startop is set to $startop
};

#
# Remove any *.bad files from previous runs.
#
unlink <*.bad>;

system("$ENV{INV_HOME}/bin/confirm_cxt_sql.csh","$db");
if ($?) {
	print "Error verifying the required sql infrastructure for inversion process\n";
	exit($?);
}    
    
print "    Start load of treepos ...",scalar(localtime),"\n";
print "$ENV{ORACLE_HOME}/bin/sqlldr $userpw\@$db control='$tmp_dir/treepos.ctl'";
print system "$ENV{ORACLE_HOME}/bin/sqlldr", "$userpw\@$db control='$tmp_dir/treepos.ctl'";
if ($?)  {
  print "Error loading treepos.\n"; 
  &ReleaseLock;
  exit $?;
}
print "\n    Loaded treepos successfully ...",scalar(localtime),"\n";

print "    Start load of source_atoms ...",scalar(localtime),"\n";
print "$ENV{ORACLE_HOME}/bin/sqlldr $userpw\@$db control='$tmp_dir/source_atoms.ctl'";
print system "$ENV{ORACLE_HOME}/bin/sqlldr", "$userpw\@$db control='$tmp_dir/source_atoms.ctl'";
if ($?)  {
  print "Error loading source_atoms.\n"; 
  &ReleaseLock;
  exit $?;
}
print "    Loaded source_atoms successfully ...",scalar(localtime),"\n";
print "\n";

if($startop == 3) { 
print "    Start load of exclude_list ...",scalar(localtime),"\n";
print system "$ENV{ORACLE_HOME}/bin/sqlldr", "$userpw\@$db control='$tmp_dir/exclude_list.ctl'";
if ($?)  {
  print "Error loading exclude_list.\n"; 
  &ReleaseLock;
  exit $?;
}
print "    Loaded exclude_list successfully ...",scalar(localtime),"\n";
print "\n";
}

# open connection
$dbh = DBI->connect("dbi:Oracle:$db", "$user", "$passwd")
   or (&ReleaseLock && die "Can't connect to Oracle database: $DBI::errstr\n");

# Enable buffer
&EnableBuffer;

# prepare statement
print "    Truncate contexts_raw, parent_treenums, context_numbers tables ...",scalar(localtime),"\n";
$sh = $dbh->prepare(qq{
    BEGIN
        MEME_SYSTEM.truncate('contexts_raw');
        MEME_SYSTEM.truncate('parent_treenums');
        MEME_SYSTEM.truncate('context_numbers');
    END;});

# execute statement & flush buffer
$sh->execute || (&ReleaseLock && die "Failed to truncate tables: $DBI::errstr\n");
&FlushBuffer;

# prepare statement
print "    Compute statistics for data tables ...",scalar(localtime),"\n";
$sh = $dbh->prepare(qq{
    BEGIN
        MEME_SYSTEM.analyze('treepos');
        MEME_SYSTEM.analyze('source_atoms');
        MEME_SYSTEM.analyze('exclude_list');
    END;});

# execute statement & flush buffer
$sh->execute || (&ReleaseLock && die "Failed to analyze tables: $DBI::errstr\n");
&FlushBuffer;

# prepare statement
print "    Run QA checks on treepos ...",scalar(localtime),"\n";
$retval = 0;
$sh = $dbh->prepare(qq{
    BEGIN
        :retval := MEME_CONTEXTS.qa_treepos;
    END;});

# bind parameters
$sh->bind_param_inout(":retval", \$retval, 12);

# execute statement & flush buffer
$sh->execute
   || (&FlushBuffer && &ReleaseLock && die "Failed to qa treepos file: $DBI::errstr\n");

if($startop != 4) {
  # prepare statement
  print "    Initialize context_numbers table ...",scalar(localtime),"\n";
  $retval = 0;
  $sh = $dbh->prepare(qq{
    BEGIN
        :retval := MEME_CONTEXTS.init_context_numbers;
    END;});

  # bind parameters
  $sh->bind_param_inout(":retval", \$retval, 12);

  # execute statement & flush buffer
  $sh->execute
   || (&FlushBuffer && &ReleaseLock && die "Failed to initialize context numbers: $DBI::errstr\n");
}

# prepare statement
print "   Generate parent_treenums  table ...",scalar(localtime),"\n";
$retval = 0;
$sh = $dbh->prepare(qq{
    BEGIN
        :retval := MEME_CONTEXTS.generate_parent_treenums;
    END;});

# bind parameters
$sh->bind_param_inout(":retval", \$retval, 12);

# execute statement & flush buffer
$sh->execute || (&FlushBuffer && &ReleaseLock && die "Failed to generate parent treenums: $DBI::errstr\n");

if($startop != 4) {
  # prepare statement
  print "   Generate ancestors ...",scalar(localtime),"\n";
  $retval = 0;
  $sh = $dbh->prepare(qq{
    BEGIN
        :retval := MEME_CONTEXTS.generate_ancestors(
			source_of_context => '$source_of_context',
                        use_rela => '$use_rela');
    END;});

  # bind parameters
  $sh->bind_param_inout(":retval", \$retval, 12);

  # execute statement & flush buffer
  $sh->execute
   || (&FlushBuffer && &ReleaseLock && die "Failed to generate ancestors: $DBI::errstr\n");
}

if($startop != 4) {
  # prepare statement
  print "   Generate children ...",scalar(localtime),"\n";
  $retval = 0;
  $sh = $dbh->prepare(qq{
    BEGIN
        :retval := MEME_CONTEXTS.generate_children(
			source_of_context => '$source_of_context',
                        use_rela => '$use_rela');
    END;});

  # bind parameters
  $sh->bind_param_inout(":retval", \$retval, 12);

  # execute statement & flush buffer
  $sh->execute
   || (&FlushBuffer && &ReleaseLock && die "Failed to generate children: $DBI::errstr\n");
}

if($startop != 1) {
  # prepare statement
  print "   Generate siblings ...",scalar(localtime),"\n";
  $retval = 0;
  $sh = $dbh->prepare(qq{
    BEGIN
        :retval := MEME_CONTEXTS.generate_siblings(
			source_of_context => '$source_of_context',
			insert_sibs => $insert_sibs,
                        use_rela => '$use_rela');
    END;});

  # bind parameters
  $sh->bind_param_inout(":retval", \$retval, 12);

  # execute statement & flush buffer
  $sh->execute
   || (&FlushBuffer && &ReleaseLock && die "Failed to generate siblings: $DBI::errstr\n");

   print "\nIf siblings were generated, there would be $retval sibling rows.\n" unless $insert_sibs;
}

if($startop != 4) {
  # prepare statement
  print "   QA checking on contexts_raw table ...",scalar(localtime),"\n";
  $retval = 0;
  $sh = $dbh->prepare(qq{
    BEGIN
        :retval := MEME_CONTEXTS.qa_contexts_raw;
    END;});

  # bind parameters
  $sh->bind_param_inout(":retval", \$retval, 12);

  # execute statement & flush buffer
  $sh->execute
   || (&FlushBuffer && &ReleaseLock && die "Failed to qa contexts: $DBI::errstr\n");

  print "\n";
  print "    Write contexts_raw table to file ...",scalar(localtime),"\n";

  open (CXTRAW,">$raw3_file_name.tmp") || (&ReleaseLock && die "Could not open $raw3_file_name.tmp: $? $!\n");

  if ($startop == 1) {
    $mrcxt_flag = "'0'";
    $mrrel_flag = "'0'";
  } else {
    $mrcxt_flag = "mrcxt_flag";
    $mrrel_flag = "mrrel_flag";
  }

  $sh = $dbh->prepare( qq{
    SELECT source_atom_id_1, context_number, context_level, sort_field, atom_name, source_atom_id_2, scd, hcd, rela, xc, source, source_of_context, mrcxt_flag, mrrel_flag
    FROM contexts_raw 
}) ||  (&ReleaseLock && die "Can't prepare statement: $DBI::errstr");

  $sh->execute;
  while (@fields = $sh->fetchrow_array) {
    $fields[7] =~ s/\r$//;
    $context_number = "    " . $fields[1];
    $fields[1] = substr($context_number, -4);
    $context_level = "  " . $fields[2];
    $fields[2] = substr($context_level, -2);
    $sort_field = "    " . $fields[3];
    $fields[3] = substr($sort_field, -4);
    # set release mode fields
    $fields[12] = "$insert_sibs";
    $fields[13] = "$insert_sibs";
    print CXTRAW join("|",@fields),"\n";
  }
  close(CXTRAW);
  (&ReleaseLock && die "Error: $sh->errstr") if $sh->err;

  unlink "$raw3_file_name";
  system "env LC_ALL=C /bin/sort -T . -o $rawdir/$raw3_file_name $raw3_file_name.tmp";
  unlink "$raw3_file_name.tmp";

  unlink "$tmp_dir/exclude_list.ctl";
  unlink "$tmp_dir/treepos.ctl";
  unlink "$tmp_dir/source_atoms.ctl";
  
# done above to simplify the handling of alt. directories
#  # add the extension if it is not there
#  if ($raw3_file_name !~ /.*\.raw3$/) {
#    $raw3_file_name .= ".raw3";
#  }
}

print qq{
-------------------------------------------------
Finished ... },scalar(localtime),qq{
-------------------------------------------------
};

&ReleaseLock;

exit 0;

####### Local Procedures #######
sub AcquireLock {
    $SIG{INT} = \&ReleaseLock;
    open (LOCK,">$tmp_dir/lock.$$") || 
       die "Could not open lockfile: $? $!\n";
    $x =  `ls $tmp_dir | egrep -c '^lock\.'`;
    if($x != 1) {
      &ReleaseLock;
      return 0;
    }
     
    print LOCK "$user_info\n";
    close(LOCK);
    return 1;
}

sub ReleaseLock {
    unlink "$tmp_dir/lock.$$";
    return 1;
}

sub EnableBuffer {
    my($size) = @_;
    $size = 100000 unless $size;
    $sh = $dbh->prepare(qq{
    BEGIN
	dbms_output.enable($size);
    END;});
    $sh->execute;
} # end EnableBuffer

sub FlushBuffer {
   #prepare stmt
    $sh = $dbh->prepare(q{
    BEGIN
	dbms_output.get_line(:line,:status);
    END;});
    #bind parms
    $sh->bind_param_inout(":line", \$line, 256);
    $sh->bind_param_inout(":status", \$status,38);

    # flush buffer
    do {
	$sh->execute;
	print "$line\n";
    } while (!$status);
    return 1;
} # end FlushBuffer

sub PrintVersion {
    my($type) = @_;
    print "Release $release: version $version, ".
          "$version_date ($version_authority).\n"
          if $type eq "version";
    print "$version\n" if $type eq "v";
    return 1;
}

sub PrintUsage {

    print qq{ This script has the following usage:
 Usage: process_contexts.pl [-d<db_name>]
    };
}

sub PrintHelp {
    &PrintUsage;
    print qq{
  This script loads the treepos and source_atoms tables
  and calls the context processing functions.  It then makes a
  <file_name>[.raw3] file from the contents of contexts_raw table.
  The various start options.
               1  generate ancestors and children only
               2  generate ancestors, children, and all siblings
               3  generate ancestors, children, and some siblings
                     (req. exclude_table)
               4  return the count of the number of siblings but
                       don't put them in .raw3 file

  $usage

  Options:
         -d<db>:                 Specify a database
         -ignore_rela:           Do not use RELA values in trees
                                 when computing children and siblings.
         -v[ersion]:             Print version information
         -[-]help:               On-line help
};
    &PrintVersion("version");
    return 1;
}

# we create our own .ctl files so that we can specify where the data
# files are to be found
sub CreateCTLfile {

open(TP_CTL, ">$tmp_dir/treepos.ctl") or die "Can't open ctl file, '$tmp_dir/treepos.ctl', $!";
print TP_CTL<<EOT;
options (rows=10000, bindsize=10000000, readsize=10000000)
load data
infile '$dir/treepos'
badfile '$dir/treepos'
discardfile '$dir/treepos'
truncate
into table treepos
fields terminated by '|' 
trailing nullcols
(
 source_atom_id         integer external,
 context_number         CONSTANT 0,
 hcd                    char(1000),
 treenum                char(1000),
 rela                   char,
 sort_field             integer external,
 source_rui             char,
 relationship_group     char
 )

EOT
close TP_CTL;

open(SA_CTL, ">$tmp_dir/source_atoms.ctl") or die "Can't open ctl file, '$tmp_dir/source_atoms.ctl', $!";
print SA_CTL<<EOT;
options (rows=10000, bindsize=10000000, readsize=10000000)
load data
infile '$dir/source_atoms'
badfile 'source_atoms'
discardfile 'source_atoms'
truncate
into table source_atoms 
fields terminated by '|' 
trailing nullcols
(source_atom_id          integer external,
 termgroup               char,
 code                    char,
 atom_name               char(3000),
 hcd                     char(1000),
 sg_id                   char(50),
 sg_type                 char(50),
 sg_qualifier            char(50)
 )
EOT
close SA_CTL;

if($startop == 3) {
open(EX_CTL, ">$tmp_dir/exclude_list.ctl") or die "Can't open ctl file, '$tmp_dir/exclude_list.ctl', $!";

print EX_CTL<<EOT;
options (rows=10000, bindsize=10000000, readsize=10000000)
load data
infile '$dir/exclude_list'
badfile '$dir/exclude_list'
discardfile '$dir/exclude_list'
truncate
into table exclude_list 
fields terminated by '|' 
trailing nullcols
(
 parnum         char,
 token          char
 )
EOT
close EX_CTL;
}

}
