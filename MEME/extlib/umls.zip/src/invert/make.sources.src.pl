#!@PATH_TO_PERL@

# script to make sources.src from a template
# copy this file and fill in the 2nd field:
#  sources.src.template

# usage: make.sources.src.s <filled-in-template> > sources.src
# if you have multiple SABs, make multiple template files and
# concatenate the output of this file,
# e.g. make.sources.src.s <2nd template> >> sources.src

while (<>)
	{
	chomp;
	next if (/^\#/);
	($tag,$value,$desc)=split(/\|/);
	print "$value|";
	}

print "\n";

